# the_journal

**OuijaCTF** | Password Cracking | Medium  
**Author:** Salman (X3muS)

---

## Story

After their close friend mysteriously disappears, four friends begin searching her bedroom for clues before entering the haunted mansion.

While searching beneath an old wooden desk, they discover a loose floorboard.  
Hidden underneath is an old leather journal.

Most of its pages have been ripped out.  
Inside the journal is a handwritten note.

> *"If you're reading this...  
> I'm probably already gone.  
> Everything I couldn't write here is inside the backup.  
> If anyone else finds it...  
> Burn it."*

Hidden between the pages is an old USB drive labelled **Journal Backup**.

The USB contains an encrypted backup of her journal.  
Only one thing could be recovered from the drive:  
a password hash.

The four friends must recover the password, decrypt the journal, and discover what happened before she disappeared.

---

## Challenge Description

You have recovered the following evidence from the missing person's bedroom:

- A photograph of the handwritten note found inside the journal
- An encrypted journal backup (`journal_backup.enc`)
- A password hash recovered from the USB drive (`hash.txt`)

Your task is to crack the password, decrypt the journal backup, and uncover the final entry.

---

## Files Included

| File | Description |
|------|-------------|
| `note.png` | Photograph of the handwritten note |
| `journal_backup.enc` | Encrypted journal backup |
| `hash.txt` | Password hash recovered from the USB |
| `readme.md` | This file |

---

## Objective

Recover the password used to encrypt the journal, decrypt `journal_backup.enc`, and extract the flag hidden inside the final diary entry.

---

*The silence in that room was never empty.*  
*Something was waiting.*
