# CTF Challenge: The Ouija Cipher

**Difficulty:** Hard
**Category:** Cryptography

## Story
A ritual paper was found lying beside an Ouija board, covered in strange
symbols that don't look like any language — but they don't look random
either.

## Files
- `ritual_paper.txt` — the recovered symbols

## Hint
> "One decoding isn't enough."

## Goal
Decode the symbols in the correct order and submit the flag in the
format `flag{...}`.

## Solve Path (spoiler — don't read until you're stuck)
<details>
<summary>Click to expand</summary>

1. The string is Base64. Decode it first:
   ```
   echo "KTkoLTopOjsoKCsxLCQePTw9PyAjKA==" | base64 -d | xxd
   ```
   This produces raw (non-printable) bytes — not the flag yet.

2. Those bytes are XOR'd with a repeating key. Given the Ouija board
   theme, try the key `OUIJA`:
   ```python
   import base64
   data = base64.b64decode("KTkoLTopOjsoKCsxLCQePTw9PyAjKA==")
   key = b"OUIJA"
   flag = bytes(b ^ key[i % len(key)] for i, b in enumerate(data))
   print(flag.decode())
   ```

3. This reveals the flag: `flag{forbidden_ritual}`

</details>
