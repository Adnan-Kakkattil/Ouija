# CTF Challenge: The Locked Drive

**Difficulty:** Hard
**Category:** Cryptography / Forensics — Password Cracking

## Story
An old USB drive was found in a storage unit, containing a single archive
labelled **"DO NOT OPEN"**. Whoever locked it clearly didn't want it read —
but they also didn't pick a very strong password.

## Files
- `locked_archive.zip` — the password-protected archive
- `wordlist.txt` — a small custom dictionary (optional starting point;
  you're also free to use `rockyou.txt` or any wordlist of your choosing)

## Hint
> "Use a dictionary attack."

## Goal
Recover the password, extract the archive, and submit the flag inside
in the format `flag{...}`.

## Solve Path (spoiler — don't read until you're stuck)
<details>
<summary>Click to expand</summary>

1. Extract the crackable hash from the zip:
   ```
   zip2john locked_archive.zip > hash.txt
   ```
2. Run John the Ripper with a wordlist:
   ```
   john --wordlist=wordlist.txt hash.txt
   ```
   (or `john --wordlist=/usr/share/wordlists/rockyou.txt hash.txt`)
3. Show the cracked password:
   ```
   john --show hash.txt
   ```
4. Unzip using the recovered password:
   ```
   unzip -P <password> locked_archive.zip
   ```
5. Read `secret.txt` for the flag.

</details>
