const express = require('express');
const fs = require('fs');
const path = require('path');
const transcriptEngine = require('./lib/transcript-engine');
const {
  reconcileSessionProfile,
  reconcileArchiveFixture,
  clampSensitivity,
  normalizeDriftMode,
} = require('./lib/case-utils');

// Snapshot of Object.prototype's own property names, taken before any
// request has been handled. Used only by the dev-only reset endpoint below
// to undo prototype pollution left over from a bad/partial exploit attempt,
// without having to restart the whole process.
const PRISTINE_PROTOTYPE_KEYS = new Set(Object.getOwnPropertyNames(Object.prototype));

const app = express();
app.use(express.json({ limit: '100kb' }));
app.use('/static', express.static(path.join(__dirname, 'public')));

// ---------------------------------------------------------------------------
//CTF Created By _sharathc
// ---------------------------------------------------------------------------
const baseFixture = {
  'SES-1958': { medium: 'Eleanor Voss', year: 1958, outcome: 'dormant', spiritActivity: 'low' },
  'SES-1974': { medium: 'Marguerite Voss', year: 1974, outcome: 'restless', spiritActivity: 'moderate' },
  'SES-1991': { medium: 'Thomas Voss', year: 1991, outcome: 'hostile', spiritActivity: 'high' },
};

const diaryAnnotations = {
  'SES-1958': { lastEntry: '2026-07-27T02:11:00Z' },
  'SES-1974': { lastEntry: '2026-07-27T01:55:00Z' },
  'SES-1991': { lastEntry: '2026-07-27T02:20:00Z' },
};

const sessions = {};
for (const id of Object.keys(baseFixture)) {
  sessions[id] = reconcileArchiveFixture({ ...baseFixture[id] }, diaryAnnotations[id] || {});
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/api/sessions', (req, res) => {
  res.json(sessions);
});

// Investigators recalibrate the planchette-tracking rig before reviewing a
// session, submitting deltas that get folded into that session's default
// rig profile.
app.post('/api/board/calibrate', (req, res) => {
  const { sessionId, settings } = req.body || {};

  if (!sessionId || typeof settings !== 'object' || settings === null || Array.isArray(settings)) {
    return res.status(400).json({ error: 'sessionId (string) and settings (object) are required' });
  }

  if (!sessions[sessionId]) {
    return res.status(404).json({ error: 'unknown sessionId' });
  }

  // Input validation: reject payloads that try to reach outside the
  // calibration object itself.
  const raw = JSON.stringify(req.body);
  if (/__proto__/i.test(raw)) {
    return res.status(400).json({ error: 'blocked: disallowed key in payload' });
  }

  const defaultProfile = { sensitivity: 1.0, driftMode: 'ambient', threshold: 0.5, unit: 'mG' };
  const appliedProfile = reconcileSessionProfile(defaultProfile, settings);

  if (typeof appliedProfile.sensitivity !== 'undefined') {
    appliedProfile.sensitivity = clampSensitivity(appliedProfile.sensitivity);
  }
  if (typeof appliedProfile.driftMode !== 'undefined') {
    appliedProfile.driftMode = normalizeDriftMode(appliedProfile.driftMode);
  }

  res.json({ sessionId, appliedProfile });
});

// Generates an HTML transcript for a recorded session.
app.get('/api/board/transcript/:id', (req, res) => {
  const session = sessions[req.params.id];
  if (!session) return res.status(404).send('Unknown session');

  const template = fs.readFileSync(path.join(__dirname, 'views', 'session-transcript.tmpl'), 'utf8');
  const html = transcriptEngine.render(template, {
    session,
    sessionId: req.params.id,
    generatedAt: new Date().toISOString(),
  });
  res.send(html);
});

// ---------------------------------------------------------------------------
// Dev-only recovery endpoint.
//
// A failed or partial pollution attempt (typo in a property name, payload
// that throws mid-way, etc.) can leave junk sitting on Object.prototype for
// the rest of this process's life, which then makes every later attempt
// look "broken" even when the technique is right. This endpoint strips any
// property from Object.prototype that wasn't there at boot, so you can
// recover without restarting the server/container.
//
// Disabled by default. Enable with ENABLE_RESET=1 in the environment.
// Do not enable this in a real competition deployment - it lets anyone
// wipe another player's in-progress pollution.
// ---------------------------------------------------------------------------
if (process.env.ENABLE_RESET === '1') {
  // Non-destructive: just lets the UI check whether reset is available,
  // without itself touching Object.prototype.
  app.get('/api/debug/reset-pollution', (req, res) => {
    res.json({ enabled: true });
  });

  // Destructive: actually strips anything added to Object.prototype since
  // boot. Only ever triggered by an explicit action (the button), never by
  // just loading a page.
  app.post('/api/debug/reset-pollution', (req, res) => {
    const removed = [];
    for (const key of Object.getOwnPropertyNames(Object.prototype)) {
      if (!PRISTINE_PROTOTYPE_KEYS.has(key)) {
        delete Object.prototype[key];
        removed.push(key);
      }
    }
    res.json({ reset: true, removedKeys: removed });
  });
  console.log('Dev reset endpoint enabled: GET (status) / POST (reset) /api/debug/reset-pollution');
}

app.use((req, res) => res.status(404).send('Not found'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Blackwood Archive terminal listening on :${PORT}`));
